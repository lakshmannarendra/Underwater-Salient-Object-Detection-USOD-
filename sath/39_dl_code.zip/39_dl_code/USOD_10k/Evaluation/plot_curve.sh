python plot_curve.py --methods GICD_retest --datasets CoCA --out_dir ./Result/Curves --res_dir ./Result/Detail
